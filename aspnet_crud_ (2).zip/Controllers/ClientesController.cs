using Microsoft.AspNetCore.Mvc;
using YourNamespace.Data;
using YourNamespace.Models;
using System.Linq;

namespace YourNamespace.Controllers
{
    public class ClientesController : Controller
    {
        private readonly LojaDbContext _context;

        public ClientesController(LojaDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var clientes = _context.Clientes.ToList();
            return View(clientes);
        }

        // Additional CRUD methods go here (Create, Read, Update, Delete)
    }
}
