using Microsoft.AspNetCore.Mvc;
using YourNamespace.Data;
using YourNamespace.Models;
using System.Linq;

namespace YourNamespace.Controllers
{
    public class ProdutosController : Controller
    {
        private readonly LojaDbContext _context;

        public ProdutosController(LojaDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var produtos = _context.Produtos.ToList();
            return View(produtos);
        }

        // Additional CRUD methods go here (Create, Read, Update, Delete)
    }
}
