using Microsoft.AspNetCore.Mvc;
using YourNamespace.Data;
using YourNamespace.Models;
using System.Linq;

namespace YourNamespace.Controllers
{
    public class VendasController : Controller
    {
        private readonly LojaDbContext _context;

        public VendasController(LojaDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var vendas = _context.Vendas.ToList();
            return View(vendas);
        }

        // Additional CRUD methods go here (Create, Read, Update, Delete)
    }
}
