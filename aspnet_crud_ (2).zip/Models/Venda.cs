namespace YourNamespace.Models
{
    public class Venda
    {
        public int Numero { get; set; }
        public DateTime Data { get; set; }
    }
}
