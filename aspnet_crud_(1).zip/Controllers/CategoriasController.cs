using Microsoft.AspNetCore.Mvc;
using YourNamespace.Data;
using YourNamespace.Models;
using System.Linq;

namespace YourNamespace.Controllers
{
    public class CategoriasController : Controller
    {
        private readonly LojaDbContext _context;

        public CategoriasController(LojaDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var categorias = _context.Categorias.ToList();
            return View(categorias);
        }

        // Additional CRUD methods go here (Create, Read, Update, Delete)
    }
}
