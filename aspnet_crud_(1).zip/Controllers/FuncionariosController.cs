using Microsoft.AspNetCore.Mvc;
using YourNamespace.Data;
using YourNamespace.Models;
using System.Linq;

namespace YourNamespace.Controllers
{
    public class FuncionariosController : Controller
    {
        private readonly LojaDbContext _context;

        public FuncionariosController(LojaDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var funcionarios = _context.Funcionarios.ToList();
            return View(funcionarios);
        }

        // Additional CRUD methods go here (Create, Read, Update, Delete)
    }
}
