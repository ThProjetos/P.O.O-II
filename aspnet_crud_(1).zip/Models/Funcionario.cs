namespace YourNamespace.Models
{
    public class Funcionario
    {
        public int Id { get; set; }
        public string Matricula { get; set; }
        public string Nome { get; set; }
    }
}
